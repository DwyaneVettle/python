# powerbi-visuals-timeseriesdecomposition
R-powered custom visual implementing the “Seasonal and Trend decomposition using Loess” algorithm, offering several types of plots. Time series decomposition is an essential analytics tool to understand the time series components and to improve forecasting.
