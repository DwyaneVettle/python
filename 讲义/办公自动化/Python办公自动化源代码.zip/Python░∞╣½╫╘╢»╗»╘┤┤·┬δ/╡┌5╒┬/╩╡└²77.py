import numpy as np

print(np.zeros((3,4)))
print("==================")
print(np.ones((2,3,4)))
print("==================")
print(np.empty((5,3)))
