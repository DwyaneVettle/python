import matplotlib.pyplot as plt

plt.subplots(nrows=1,ncols=1,sharex=False,sharey=False)

plt.show()
