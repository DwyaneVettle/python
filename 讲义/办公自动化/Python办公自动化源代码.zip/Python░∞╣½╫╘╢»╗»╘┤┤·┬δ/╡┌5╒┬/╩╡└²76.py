import numpy as np
print(np.arange(15).reshape(5,3))  #创建二维数组并输出
print("==================")
print(np.arange(10,30,5))          #创建一维数组并输出
print("==================")
print(np.arange(0,2,0.3))          #创建一维数组并输出
print("==================")
print(np.linspace(0,2,9))          #创建一维数组并输出
