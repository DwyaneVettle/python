import matplotlib.pyplot as plt
import numpy as np
fig,axes=plt.subplots(2,2,figsize=(9,9))
fig.subplots_adjust(wspace=0.5,hspace=0.3,left=0.125,right=0.9,top=0.9,bottom=0.1)

plt.show()
