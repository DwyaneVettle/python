import matplotlib.pyplot as plt

fig=plt.figure()
ax=fig.add_subplot(111)

plt.show()
