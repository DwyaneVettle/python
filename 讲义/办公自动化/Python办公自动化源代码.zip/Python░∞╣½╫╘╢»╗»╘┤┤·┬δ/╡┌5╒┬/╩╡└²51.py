import matplotlib.pyplot as plt
plt.figure()                    			#创建绘图区域
plt.plot([0,5],[2,7],linewidth=5,linestyle='solid')	#绘制直线

plt.show()
