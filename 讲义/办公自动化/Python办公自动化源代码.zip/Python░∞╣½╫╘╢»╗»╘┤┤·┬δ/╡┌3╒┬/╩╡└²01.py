import pandas as pd           	#调用库
df=pd.DataFrame()           	#创建空的Excel表格
df.to_excel('d:/abc/311.xlsx')   	#保存位置
