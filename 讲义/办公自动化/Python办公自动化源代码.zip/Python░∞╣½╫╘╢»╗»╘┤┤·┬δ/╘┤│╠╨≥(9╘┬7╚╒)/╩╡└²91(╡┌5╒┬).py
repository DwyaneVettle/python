import numpy as np
print(np.array(object=[1,2,3,4,5,6],dtype=complex))  
print("===========")
print(np.array(np.arange(10),dtype=float))  #生成数组序列
print("===========")
print(np.array(np.arange(10),ndmin=2))  #定义最小维度的ndarray映象

















