import numpy as np
x=np.array([[1.0,3.0,0.0],[0.0,1.0,2.0]]) #定义二维数组,大小为(2,3)

print(x)
print(x.ndim)     #输出数组维度数
print(x.shape)    #输出数组的维数
print(x.size)     #输出数组元素的总数
print(x.dtype)    #输出数组元素类型

















