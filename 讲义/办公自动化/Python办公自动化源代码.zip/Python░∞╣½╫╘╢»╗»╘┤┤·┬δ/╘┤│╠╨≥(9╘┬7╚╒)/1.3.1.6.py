from turtle import *
while True:
    fd(200)
    rt(144)
    if abs(pos())<1:
        break

