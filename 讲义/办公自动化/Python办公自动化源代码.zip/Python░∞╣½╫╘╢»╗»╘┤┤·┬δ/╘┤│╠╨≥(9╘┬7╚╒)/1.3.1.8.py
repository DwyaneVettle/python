count=0
while count<10:
    count+=1
    if int(count/2)==count/2:
        continue     #满足条件重新判断
    print(count)


