for i in range(3,9):
    print(i,end=" ")
