import numpy as np

a=np.array([20,30,40,50])
b=np.arange(1,5)
print(a/b)              #计算除
print("===========")  
c=np.arange(4)
print(c)
print("===========")
d=a-c                   #计算减
print(d)
print("===========")
print(c**2)             #计算乘方
print("===========")
e=np.array([[1,1],[0,1]])
print(e)
print("===========")
f=np.array([[2,0],[3,4]])
print(f)
print("===========")
print(e*f)              #计算乘
print("===========")
print(e.sum())          #求和
print("===========")
print(e.min())          #求最小值 
print("===========")
print(e.max())          #求最大值

















