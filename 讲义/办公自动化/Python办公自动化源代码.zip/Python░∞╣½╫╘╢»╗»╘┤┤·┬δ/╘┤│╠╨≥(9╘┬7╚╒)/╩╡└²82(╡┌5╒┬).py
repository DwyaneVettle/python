import numpy as np
a=np.matrix('1.0 2.0;3.0,4.0')
print(a)
print("===========")
b=np.matrix([[1.0,2.0],[3.0,4.0]])
print(b)
print("===========")
print(type(a))
print(type(b))


















