import numpy as np
a=np.array([1,2,3])
b=np.array([0,1,0])
print(a)
print("===========")
print(b)
print("===========")
print(np.inner(a,b))   #等价于1*0+2*1+3*0



















