import matplotlib.pyplot as plt
plt.figure()                                                           #创建绘图区域
plt.plot([0,5],[1,6],[0,5],[8,13],linewidth=5,linestyle='solid') #绘制直线

plt.show()






