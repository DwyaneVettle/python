from openpyxl import Workbook 
wb = Workbook()                     #创建文件
wb.save(r"d:\abc\561.xlsx")       #保存文件
