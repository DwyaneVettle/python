n=input("请输入一个整数N：")
if int(n)%2==0:
    print(str(n)+"是偶数")
else:
    print(str(n)+"是奇数")

