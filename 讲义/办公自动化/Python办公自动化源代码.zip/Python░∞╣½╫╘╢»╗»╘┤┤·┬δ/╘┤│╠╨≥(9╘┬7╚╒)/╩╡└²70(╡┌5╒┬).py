import matplotlib.pyplot as plt
import numpy as np

for i,color in enumerate('rgbyck'):
    plt.subplot(321+i,facecolor=color)
plt.show()















