import matplotlib.pyplot as plt
fig=plt.figure()

plt.show()




