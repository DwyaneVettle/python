import matplotlib.pyplot as plt
import numpy as np

plt.subplots(nrows=1,ncols=1,sharex=False,sharey=False,squeeze=True,subplot_kw=None)

plt.show()















