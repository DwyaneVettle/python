count=0
while True:
    count+=1
    print(count)
    if count>9:
        break        #中断，跳出循环

