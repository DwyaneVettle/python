import pandas as pd
import matplotlib .pyplot as plt
plt.rcParams['font.sans-serif']=['SimHei']    	#设置默认字体
plt.rcParams['axes.unicode_minus']=False   	#正常显示负号

stu=pd.read_excel('d:/abc/例题锦集.xlsx',sheet_name="销售数量")

stu.plot(y='农夫山泉')     #建立折线图

plt.show()
