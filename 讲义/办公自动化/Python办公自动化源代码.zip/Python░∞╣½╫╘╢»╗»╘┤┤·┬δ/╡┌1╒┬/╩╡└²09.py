for i in range(1,101):
    if int(i/7)==i/7:
        print(i,end=" ")
