count=0
while True:
    count+=2
    print(count, end=" ")
    if count>19:
        break        #中断，跳出循环
