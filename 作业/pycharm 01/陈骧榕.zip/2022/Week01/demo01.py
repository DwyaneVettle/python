import turtle
turtle.width(10)
turtle.color("green")

turtle.goto(0,0)
turtle.goto(0,100)
turtle.goto(100,100)
turtle.goto(100,0)
turtle.goto(0,0)
turtle.penup()

turtle.goto(120,0)
turtle.pendown()
turtle.goto(120,0)
turtle.goto(120,100)
turtle.goto(220,100)
turtle.goto(220,0)
turtle.goto(120,0)
turtle.penup()

turtle.goto(-100,-50)
turtle.pendown()
turtle.goto(-100,-50)
turtle.goto(-200,-50)
turtle.goto(-200,-150)
turtle.goto(-100,-150)
turtle.goto(-100,-50)
turtle.penup()

turtle.goto(0,-50)
turtle.pendown()
turtle.goto(0,-50)
turtle.goto(0,-150)
turtle.goto(100,-150)
turtle.goto(100,-50)
turtle.goto(0,-50)

turtle.done()

