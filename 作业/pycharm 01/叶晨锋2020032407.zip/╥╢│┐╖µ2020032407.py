# 2022/2/21/18:54
# 作业
import turtle
t = turtle.Pen()
# 第一个正方形
for x in range(4):
    t.forward(100)
    t.left(90)

# 第二个正方形
turtle.penup()
turtle.goto(150,0)
turtle.pendown()
for x in range(4):
    turtle.forward(100)
    turtle.left(90)

# 第三个正方形
turtle.penup()
turtle.goto(0,-150)
turtle.pendown()
for x in range(4):
    turtle.forward(100)
    turtle.left(90)

# 第四个正方形
turtle.penup()
turtle.goto(150,-150)
turtle.pendown()
for x in range(4):
    turtle.forward(100)
    turtle.left(90)



