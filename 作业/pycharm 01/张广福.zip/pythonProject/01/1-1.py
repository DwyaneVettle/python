import turtle

pen = turtle.Pen()

for x in range(360):
    pen.forward(x)
    pen.left(59)
