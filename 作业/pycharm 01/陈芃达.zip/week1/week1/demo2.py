import turtle

# 第一个圆
turtle.width(15)
turtle.color("blue")
turtle.circle(60)

# 第二个圆
turtle.color("black")
turtle.penup()
turtle.goto(150,0)
turtle.pendown()
turtle.width(15)
turtle.circle(60)

# 第三个圆
turtle.color("red")
turtle.penup()
turtle.goto(300,0)
turtle.pendown()
turtle.width(15)
turtle.circle(60)

# 第四个圆
turtle.color("yellow")
turtle.penup()
turtle.goto(75,-60)
turtle.pendown()
turtle.width(15)
turtle.circle(60)
# 第五个圆
turtle.color("green")
turtle.penup()
turtle.goto(225,-60)
turtle.pendown()
turtle.width(15)
turtle.circle(60)












