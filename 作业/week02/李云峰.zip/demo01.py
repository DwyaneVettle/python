#作业1.熟悉python安装环境 2.画正方形
import turtle
turtle.title("正方形")
turtle.pensize(5)
turtle.pencolor("red")
for i in range(4):
    turtle.forward(200)
    turtle.left(90)
#第二个正方形
turtle.penup()
turtle.goto(220,0)
turtle.pendown()
for i in range(4):
    turtle.forward(200)
    turtle.left(90)
#第三个正方形
turtle.penup()
turtle.goto(220,-220)
turtle.pendown()
for i in range(4):
    turtle.forward(200)
    turtle.left(90)
#第四个正方形
turtle.penup()
turtle.goto(0,-220)
turtle.pendown()
for i in range(4):
    turtle.forward(200)
    turtle.left(90)
turtle.done()