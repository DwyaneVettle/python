import turtle

turtle.width(5)
turtle.color("orange")

for i in range(4):
    turtle.forward(50)
    turtle.right(90)

turtle.penup()
turtle.goto(70, 0)
turtle.pendown()

for i in range(4):
    turtle.forward(50)
    turtle.right(90)

turtle.penup()
turtle.goto(0, -70)
turtle.pendown()

for i in range(4):
    turtle.forward(50)
    turtle.right(90)

turtle.penup()
turtle.goto(70, -70)
turtle.pendown()

for i in range(4):
    turtle.forward(50)
    turtle.right(90)
