import turtle

turtle.width(20)
turtle.color("blue")

#第一个
turtle.goto(0,0)
turtle.goto(0,100)
turtle.goto(100,100)
turtle.goto(100,0)
turtle.goto(0,0)
turtle.penup()

#第二个
turtle.goto(-100,0)
turtle.pendown()
turtle.goto(-100,0)
turtle.goto(-100,100)
turtle.goto(-200,100)
turtle.goto(-200,0)
turtle.goto(-100,0)
turtle.penup()

#第三个
turtle.goto(-100,-50)
turtle.pendown()
turtle.goto(-100,-50)
turtle.goto(-200,-50)
turtle.goto(-200,-150)
turtle.goto(-100,-150)
turtle.goto(-100,-50)
turtle.penup()

#第四个

turtle.goto(0,-50)
turtle.pendown()
turtle.goto(0,-50)
turtle.goto(0,-150)
turtle.goto(100,-150)
turtle.goto(100,-50)
turtle.goto(0,-50)

turtle.done()