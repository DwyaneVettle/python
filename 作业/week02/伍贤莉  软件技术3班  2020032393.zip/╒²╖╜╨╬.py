import turtle 

# 第一个正方形
turtle.width(5)
turtle.color("crimson")
turtle.goto(0,0)
turtle.goto(0,100)
turtle.goto(100,100)
turtle.goto(100,0)
turtle.goto(0,0)
turtle.penup()

# 第二个正方形
turtle.width(5)
turtle.color("crimson")
turtle.goto(-50,0)
turtle.pendown()
turtle.goto(-50,0)
turtle.goto(-50,100)
turtle.goto(-150,100)
turtle.goto(-150,0)
turtle.goto(-50,0)
turtle.penup()

# 第三个正方形
turtle.width(5)
turtle.color("crimson")
turtle.goto(-50,-50)
turtle.pendown()
turtle.goto(-50,-50)
turtle.goto(-150,-50)
turtle.goto(-150,-150)
turtle.goto(-50,-150)
turtle.goto(-50,-50)
turtle.penup()

# 第四个正方形
turtle.width(5)
turtle.color("crimson")
turtle.goto(0,-50)
turtle.pendown()
turtle.goto(0,-50)
turtle.goto(0,-150)
turtle.goto(100,-150)
turtle.goto(100,-50)
turtle.goto(0,-50)

# 箭头消失
turtle.hideturtle()
turtle.ht()

