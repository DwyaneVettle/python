i=0
j=0
k=0
while i<=100:
    if i%2==0:
        j+=i
    else:
        k+=i
    i+=1  #自增
print("100以内偶数的和:",j)
