# author by ycf
# 2022/3/19 11:28
# 1、用for循环和while循环求100以内偶数的和
num = 0
a = 0
while a <= 100:
    if a % 2 == 0:
        num = num + a
        print(a)
    a = a + 1
print('while循环1~100之间的偶数和',num)

sum = 0
for n in range(1,101):
    if n %2 == 0:
        sum += n
print('for循环1到100的偶数和为：',sum)
# 2、嵌套for循环打印99乘法表
for i in range(1,10):
    print()
    for c in range(1,i+1):
        print("%d*%d=%d" % (c,i,c*i), end=" ")

