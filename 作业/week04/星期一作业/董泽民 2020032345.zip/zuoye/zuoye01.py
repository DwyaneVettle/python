# 2022/3/16 10:05
# 1.用for循环和while循环求100以内偶数的和

num = 0
for i in range(1, 101):
    if i % 2 == 0:  # 不被2整除
        num = num + i
    print(num)
