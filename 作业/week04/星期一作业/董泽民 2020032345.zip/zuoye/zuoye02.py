# 2022/3/16 10:10
# 2.嵌套for循环打印99乘法表
import row as row

for num1 in range(1, 10):
    for num2 in range(1, 10):
        print(num1, "X", num2, "=", num1 * num2, "\t", end="")
        if num1 == num2:
            print("")
            break
