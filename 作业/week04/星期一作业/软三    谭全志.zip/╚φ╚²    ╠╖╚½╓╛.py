# 九九乘法表
for i in range(1,10):
    for j in range(1,i+1):
        print(f'{j}*{i}={j*i}',end='\t')
    print()



i = 1
while i <= 9:
    j = 1
    while(j <= i):
        print(f'{i}*{j}={i*j}',end='\t')
        j += 1
    print('')
    i += 1


# 100以内的偶数和
sum = 0
for i in range(0,101,2):
    sum += i
print(sum)



sum = 0
i = 0
while i <=100:
    sum += i
    i += 2
print(sum)
