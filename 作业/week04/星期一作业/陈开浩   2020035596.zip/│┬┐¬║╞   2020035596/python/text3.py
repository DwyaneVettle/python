for i in range(1, 10):
    s = ''  # 每次将s清空
    for j in range(1, i+1):
         s += str(j) + '*' + str(i) + '=' + str(i*j) + ' '
    print(s)




