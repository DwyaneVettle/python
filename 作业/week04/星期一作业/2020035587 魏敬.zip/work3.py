j=0
for i in range(1,101):
    if i%2==0:
        j+=i
print("100以内的偶数和为:",j)





