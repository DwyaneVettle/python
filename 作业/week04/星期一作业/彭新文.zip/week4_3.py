# pxw
# 2022/3/20 20:28
#嵌套for循环打印99乘法表
for i in range(1, 10):
    s = ''  # 每次将s清空
    for j in range(1, i+1):
         s += str(j) + '*' + str(i) + '=' + str(i*j) + ' '
         print(s)
