# pxw
# 2022/3/20 20:14
#用for循环求100以内的偶数的和
j=0
for i in range(1,101):
    if i%2==0:
        j+=i
        print("100以内的偶数和为:",j)
