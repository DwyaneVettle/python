# author Basui
# 2022/3/20 20:40
i = 0
j = 0
k = 0
while i <= 100:
    if i % 2 == 0:
        j += i
    else:
        k += i
    i += 1
print("100以内偶数和:", j)