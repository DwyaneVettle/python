# while循环
# 创建一个变量x初始化为2
x = 2
# 创建一个变量sum初始化为0
sum = 0
# 使用while循环求出0-100所有偶数的和
while x <= 100 :
# +=是加赋值运算符，sum+=i相当于sum=sum+i，
# 即表示首先先计算sum和i的和，再将其和赋予给新的sum。
	sum += x
	x += 2
# 打印输出求和结果：2550
print(sum)

# for in循环
# 定义一个变量，初始为0
num=0
# 使用for()函数，range从1到100（取值范围为逗号后前一位）
for i in range(1,101):
# 注意“i%2”等价于“不被2整除”，
    if i%2 == 0:#此处注意冒号
        num += i  #num = num + i
# 打印
