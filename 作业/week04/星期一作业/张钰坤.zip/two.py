for i in range(1, 10):
    for j in range(1, 10):
        if j <= i:  # 第几层打印几个
            sum = i * j
            print(' %d*%d=%d' % (j, i, sum), end='')  # 控制打印完不换行
    print()  # 控制打印完换行


for i in range(1, 10):
    for j in range(1, 10):
        if i <= j:
            sum = i * j
            print(' %d*%d=%d' % (i, j, sum), end='')
    print()

