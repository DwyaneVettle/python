# 2022/3/20 19:48
for i in range(1, 10):
    for j in range(1, i+1):
        print(f'{j}x{i}={j*i}', end=' ')
    print()