"""
日期2022年03月19日--16:12
 encodings ="UTF-8"
使用工具：PyCharm
"""
num = 0
a = 0
while a <= 100:
    if a % 2 == 0:
        num = num + a
        print(a)
    a = a + 1
print('while循环1~100之间的偶数和',num)

z=0
for n in range(1,101):
    if n %2 == 0:
        z += n
print('for循环1到100的偶数和为：',z)