#用for循环和while表100以内偶数的和

i=1
sum=0
while i<=100:
	if i%2==0:
		sum+=i
	i+=1
print("1-100之间偶数的和是：%d"%sum)

sum1 = 0
for i in range(1,101):
    if i % 2 == 0:
        sum1 = sum1 +i
    i += 1
print(f"1-100之间偶数的和是：{sum1}")