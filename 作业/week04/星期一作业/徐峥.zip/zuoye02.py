# author by Michealzou@126.com
# 2022/3/20 17:52
sum = 0
a = 0
while a < 100 :
    a = a + 1
    if a % 2 == 0 :
        sum = sum + a
        print('1到100间的偶数和',sum)

sum1 = 0
i = 0
for i in range(0,100) :
    if i % 2 == 0 :
        i = i + 1
        sum1 = sum1 + i
        print('1到100的偶数和',sum1)



for i in range(1,10):
    for j in  range(1,i+1) :
        print(i,'*',j,'=',i*j,end='')
        print()
