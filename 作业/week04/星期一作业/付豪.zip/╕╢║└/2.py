# author by fh
# 日期2022年03月20日--19:31
# 使用工具：PyCharm
for i in range(1,10):
    print()
    for c in range(1,i+1):
        print("%d*%d=%d" % (c,i,c*i), end=" ")

