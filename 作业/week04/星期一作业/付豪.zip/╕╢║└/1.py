# author by fh
# 日期2022年03月20日--19:28
# 使用工具：PyCharm
num = 0
a = 0
while a <= 100:
    if a % 2 == 0:
        num = num + a
        print(a)
    a = a + 1
print('while循环：',num)

sum = 0
for n in range(1,101):
    if n %2 == 0:
        sum += n
print('for循环：',sum)
