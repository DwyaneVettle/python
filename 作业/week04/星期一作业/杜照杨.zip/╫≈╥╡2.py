"""
日期2022年03月20日--16:18
 encodings ="UTF-8"
使用工具：PyCharm
"""
for i in range(1, 10):
    print()
    for j in range(1, i + 1):
        print("%d*%d=%d" % (j, i, j * i), end=" ")
