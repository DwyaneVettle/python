package com.sccs.spring.Test;

import com.sccs.spring.bean.Emp;
import com.sccs.spring.orders.Book;
import com.sccs.spring.orders.Orders;
import com.sccs.spring.pojo.Person;
import com.sccs.spring.service.UserService;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class TestBean {
    //构造方法
    @Test
    public void test(){
        ApplicationContext context = new ClassPathXmlApplicationContext("com/sccs/spring/resources/spring-config01.xml");
        Orders orders = context.getBean("orders", Orders.class);
        System.out.println(orders);
        orders.testOrd();
    }
    //p命名
    @Test
    public void test2(){
        ApplicationContext context = new ClassPathXmlApplicationContext("com/sccs/spring/resources/spring-config01.xml");
        Book book = context.getBean("Book", Book.class);
        System.out.println(book);
        book.test();
    }
    //外部bean
    @Test
    public void test03(){
        ApplicationContext context = new ClassPathXmlApplicationContext("com/sccs/spring/resources/spring-config01.xml");
        UserService userService = context.getBean("userService", UserService.class);
        userService.add();
    }
    //内部bean
    @Test
    public void test04(){
        ApplicationContext context = new ClassPathXmlApplicationContext("com/sccs/spring/resources/spring-config01.xml");
        Person person = context.getBean("person", Person.class);
        person.man();
    }
    
    @Test
    public void test05(){
        ApplicationContext context = new ClassPathXmlApplicationContext("com/sccs/spring/resources/spring-config02.xml");
        Emp emp = context.getBean("emp", Emp.class);
        emp.add();
    }

}
