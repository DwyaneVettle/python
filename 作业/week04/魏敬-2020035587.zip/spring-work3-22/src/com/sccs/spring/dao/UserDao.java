package com.sccs.spring.dao;

public interface UserDao {
    public void update();
}
