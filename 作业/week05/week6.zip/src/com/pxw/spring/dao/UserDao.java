package com.pxw.spring.dao;

public interface UserDao {
    public void update();
}
